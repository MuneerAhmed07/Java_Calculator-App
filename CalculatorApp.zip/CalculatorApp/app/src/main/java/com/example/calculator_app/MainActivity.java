package com.example.calculator_app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView num1;
    private TextView num2;
    private Button add;
    private Button sub;
    private Button multi;
    private Button divide;
    private TextView Result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        num1 = findViewById(R.id.text1);
        num2 = findViewById(R.id.text2);
        add = findViewById(R.id.button);
        Result = findViewById(R.id.result1);
        sub = findViewById(R.id.button2);
        multi = findViewById(R.id.button3);
        divide = findViewById(R.id.button4);

        // For Addition

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());
                int sum = number1 + number2;
                Result.setText("Answer: " + String.valueOf(sum));
            }
        });

        // For subtraction

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());
                int sum = number1 - number2;
                Result.setText("Answer: " + String.valueOf(sum));
            }
        });

        // For Multiplication

        multi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());
                int sum = number1 * number2;
                Result.setText("Answer: " + String.valueOf(sum));
            }
        });

        // For Division

        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int number1 = Integer.parseInt(num1.getText().toString());
                int number2 = Integer.parseInt(num2.getText().toString());
                int sum = number1 / number2;
                Result.setText("Answer: " + String.valueOf(sum));
            }
        });

    }
}